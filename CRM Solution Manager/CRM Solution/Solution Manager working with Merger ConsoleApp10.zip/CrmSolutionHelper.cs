﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using MsCrmTools.SolutionComponentsMover.AppCode;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel.Description;

namespace ConsoleApp10
{
    internal class CrmSolutionHelper : ICrmSolutionHelper
    {
        public string RepositoryUrl { get; set; }
        public string Branch { get; set; }
        public bool CanPush { get; set; }
        public List<SolutionFileInfo> SolutionFileInfos { get; set; }

        private ClientCredentials ClientCredentials { get; set; }

        private Uri ServiceUri { get; set; }

        public CrmSolutionHelper(string repositoryUrl, string branch, string organizationServiceUrl, string userName, string password)
        {
            this.RepositoryUrl = repositoryUrl;
            this.Branch = branch;

            ServiceUri = new Uri(organizationServiceUrl);
            ClientCredentials = new ClientCredentials();
            ClientCredentials.UserName.UserName = userName;
            ClientCredentials.UserName.Password = password;
            InitializeOrganizationService();
        }

        private OrganizationServiceProxy InitializeOrganizationService()
        {
            return new OrganizationServiceProxy(ServiceUri, null, ClientCredentials, null);
        }

        public List<SolutionFileInfo> DownloadSolutionFile(string solutionUnqiueName, string owner, string message)
        {
            InitializeOrganizationService();
            CanPush = false;
            List<SolutionFileInfo> solutionFileInfos = new List<SolutionFileInfo>();
            Console.WriteLine("Connecting to the " + ServiceUri.OriginalString);
            var serviceProxy = InitializeOrganizationService();
            EntityCollection querySampleSolutionResults = FetchSourceControlQueues(serviceProxy);

            for (int i = 0; i < querySampleSolutionResults.Entities.Count; i++)
            {
                //Creates the Export Request
                SolutionFileInfo solutioninfo = null;
                try
                {
                    solutioninfo = ExportSolution(serviceProxy, querySampleSolutionResults.Entities[i]);
                    solutionFileInfos.Add(solutioninfo);
                    
                    if (solutioninfo.CheckInSolution)
                        CanPush = true;
                }
                catch (Exception ex)
                {
                    solutioninfo.Solution[Constants.SourceControlQueueAttributeNameForStatus] = "Error +" + ex.Message;
                    solutioninfo.Update();
                }
            }

            return solutionFileInfos;
        }

        private static EntityCollection FetchSourceControlQueues(OrganizationServiceProxy serviceProxy)
        {
            QueryExpression querySampleSolution = new QueryExpression
            {
                EntityName = Constants.sounceControlQueue,
                ColumnSet = new ColumnSet() { AllColumns = true },
                //ColumnSet = new ColumnSet("syed_solutionname", "syed_status", "syed_repositoryurl", "syed_comment", "syed_branch", "ownerid", "syed_includeinrelease"),
                Criteria = new FilterExpression()
            };

            querySampleSolution.Criteria.AddCondition(Constants.SourceControlQueueAttributeNameForStatus, ConditionOperator.Equal, Constants.SourceControlQueueQueuedStatus);

            Console.WriteLine("Fetching Solutions to be copied to Repository ");
            EntityCollection querySampleSolutionResults = serviceProxy.RetrieveMultiple(querySampleSolution);
            return querySampleSolutionResults;
        }

        public IEnumerable<EntityMetadata> GetSolutionEntities(string SolutionUniqueName, IOrganizationService Service)
        {
            // get solution components for solution unique name
            QueryExpression componentsQuery = new QueryExpression
            {
                EntityName = "solutioncomponent",
                ColumnSet = new ColumnSet("objectid", "solutioncomponent", "solution", "solutionid", "solutionid", "syed_sourcensolutions"),
                Criteria = new FilterExpression(),
            };
            //LinkEntity solutionLink = new LinkEntity("solutioncomponent", "solution", "solutionid", "solutionid", "syed_sourcensolutions", JoinOperator.Inner);
            //solutionLink.LinkCriteria = new FilterExpression();
            //solutionLink.LinkCriteria.AddCondition(new ConditionExpression("uniquename", ConditionOperator.Equal, SolutionUniqueName));
            //componentsQuery.LinkEntities.Add(solutionLink);
            componentsQuery.Criteria.AddCondition(new ConditionExpression("componenttype", ConditionOperator.Equal, 1));
            EntityCollection ComponentsResult = Service.RetrieveMultiple(componentsQuery);
            //Get all entities
            RetrieveAllEntitiesRequest AllEntitiesrequest = new RetrieveAllEntitiesRequest()
            {
                EntityFilters = EntityFilters.Entity | Microsoft.Xrm.Sdk.Metadata.EntityFilters.Attributes,
                RetrieveAsIfPublished = true
            };

            RetrieveAllEntitiesResponse AllEntitiesresponse = null;
            try
            {
                AllEntitiesresponse = (RetrieveAllEntitiesResponse)Service.Execute(AllEntitiesrequest);
            }
            catch (Exception ex)
            {
            }
            //Join entities Id and solution Components Id
            return AllEntitiesresponse.EntityMetadata.Join(ComponentsResult.Entities.Select(x => x.Attributes["objectid"]), x => x.MetadataId, y => y, (x, y) => x);
        }

        private void MergeSolutions(SolutionFileInfo solutionFileInfo, OrganizationServiceProxy organizationServiceProxy)
        {
            SolutionManager solutionManager = new SolutionManager(organizationServiceProxy);
            solutionManager.CopyComponents(solutionFileInfo);
        }

        private SolutionFileInfo ExportSolution(OrganizationServiceProxy serviceProxy, Entity solution)
        {
            SolutionFileInfo solutionFile = new SolutionFileInfo(solution, serviceProxy);
            if (solutionFile.SolutionsToBeMerged.Count > 0)
            {
                MergeSolutions(solutionFile, serviceProxy);
            }

            if (!solutionFile.CheckInSolution)
                return solutionFile;

            solutionFile.Solution[Constants.SourceControlQueueAttributeNameForRepositoryUrl] = RepositoryUrl;
            solutionFile.Solution[Constants.SourceControlQueueAttributeNameForBranch] = Branch;
            solutionFile.Solution[Constants.SourceControlQueueAttributeNameForStatus] = Constants.SourceControlQueueExportStatus;
            solutionFile.Update();

            string tempFolder = Path.GetTempFileName();
            ExportSolutionRequest exportRequest = new ExportSolutionRequest();
            exportRequest.Managed = true;
            exportRequest.SolutionName = solutionFile.SolutionUniqueName;

            Console.WriteLine("Downloading Solutions");
            ExportSolutionResponse exportResponse = (ExportSolutionResponse)serviceProxy.Execute(exportRequest);

            //Handles the response
            byte[] downloadedSolutionFile = exportResponse.ExportSolutionFile;
            solutionFile.SolutionFilePath = Path.GetTempFileName();
            File.WriteAllBytes(solutionFile.SolutionFilePath, downloadedSolutionFile);

            string solutionExport = string.Format("Solution Successfully Exported to {0}", solutionFile.SolutionUniqueName);
            Console.WriteLine(solutionExport);

            solutionFile.Solution[Constants.SourceControlQueueAttributeNameForStatus] = Constants.SourceControlQueueExportSuccessful;
            solutionFile.Update();

            return solutionFile;
        }
    }
}