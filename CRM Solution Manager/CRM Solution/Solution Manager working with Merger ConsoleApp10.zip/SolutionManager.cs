﻿using ConsoleApp10;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace MsCrmTools.SolutionComponentsMover.AppCode
{
    internal class SolutionManager
    {
        private readonly IOrganizationService service;

        public SolutionManager(IOrganizationService service)
        {
            this.service = service;
        }

        private IEnumerable<Entity> RetrieveSolutions()
        {
            var qe = new QueryExpression
            {
                EntityName = "solution",
                ColumnSet = new ColumnSet(new[]{
                                            "publisherid", "installedon", "version",
                                            "uniquename", "friendlyname", "description",
                                            "ismanaged"
                                        }),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("isvisible", ConditionOperator.Equal, true),
                        new ConditionExpression("uniquename", ConditionOperator.NotEqual, "Default")
                    }
                }
            };

            return service.RetrieveMultiple(qe).Entities;
        }

        private void CopyComponents(CopySettings settings, BackgroundWorker backgroundWorker)
        {
            //backgroundWorker.ReportProgress(0, "Retrieving source solution(s) components...");

            var components = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList(), settings.ComponentsTypes);

            foreach (var target in settings.TargetSolutions)
            {
                //backgroundWorker.ReportProgress(0, string.Format("Adding {0} components to solution '{1}'", components.Count, target.GetAttributeValue<string>("friendlyname")));

                foreach (var component in components)
                {
                    var request = new AddSolutionComponentRequest
                    {
                        AddRequiredComponents = false,
                        ComponentId = component.GetAttributeValue<Guid>("objectid"),
                        ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
                        SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
                    };

                    //// If CRM 2016 or above, handle subcomponents behavior
                    //if (settings.ConnectionDetail.OrganizationMajorVersion >= 8)
                    //{
                    request.DoNotIncludeSubcomponents =
                        component.GetAttributeValue<OptionSetValue>("rootcomponentbehavior")?.Value == 1 ||
                        component.GetAttributeValue<OptionSetValue>("rootcomponentbehavior")?.Value == 2;
                    //}

                    service.Execute(request);
                }
            }
        }

        private List<Entity> RetrieveComponentsFromSolutions(List<Guid> solutionsIds, List<int> componentsTypes)
        {
            var qe = new QueryExpression("solutioncomponent")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("solutionid", ConditionOperator.In, solutionsIds.ToArray()),
                        //comment below for all components
                        new ConditionExpression("componenttype", ConditionOperator.In, componentsTypes.ToArray())
                    }
                }
            };

            return service.RetrieveMultiple(qe).Entities.ToList();
        }

        public void CopyComponents(SolutionFileInfo solutionFileInfo)
        {
            solutionFileInfo.Solution[Constants.SourceControlQueueAttributeNameForStatus] = Constants.SourceControlQueuemMergingStatus;
            solutionFileInfo.Update();
            var solutions = RetrieveSolutions();
            CopySettings copySettings = GetCopySettings();
            foreach(var solution in solutions)
            {
                if (solution["uniquename"].Equals(solutionFileInfo.SolutionUniqueName))
                {
                    copySettings.TargetSolutions.Add(solution);
                }
                else if(solutionFileInfo.SolutionsToBeMerged.Any(cc=>cc.Equals(solution["uniquename"])))
                {
                    copySettings.SourceSolutions.Add(solution);
                }
            }

            CopyComponents(copySettings, new BackgroundWorker());
            solutionFileInfo.Solution[Constants.SourceControlQueueAttributeNameForStatus] = Constants.SourceControlQueuemMergingSuccessfulStatus;
            solutionFileInfo.Update();
        }

        private CopySettings GetCopySettings()
        {
            CopySettings copySettings = new CopySettings() { ComponentsTypes=new List<int>(), SourceSolutions = new List<Entity>(), TargetSolutions = new List<Entity>() };
            //for entities
            copySettings.ComponentsTypes.AddRange(Constants.ComponentTypes);


            return copySettings;
        }
    }
}