﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    internal class Constants
    {
        public const string sounceControlQueue = "syed_sourcecontrolqueue";
        public const string SourceControlQueueAttributeNameForStatus = "syed_status";
        public const string SourceControlQueueCompletedStatus = "Completed";
        public const string SourceControlQueueQueuedStatus = "Queued";
        public const string SourceControlQueueExportStatus = "Exporting";
        public const string SourceControlQueueExportSuccessful = "Export Successful";
        public const string SourceControlQueuemMergingStatus = "Merging Solutions";
        public const string SourceControlQueuemMergingSuccessfulStatus = "Merge Successful";
        public const string SourceControlQueuemPushingToStatus = "Pushing to Repository";
        public const string SourceControlQueuemPushToRepositorySuccessStatus = "Successfully Pushed To Repository";
        public const string SourceControlQueueAttributeNameForRepositoryUrl = "syed_repositoryurl";
        public const string SourceControlQueueAttributeNameForBranch = "syed_branch";

        public const string SourceControlQueueAttributeNameForSolutionName = "syed_solutionname";
        public const string SourceControlQueueAttributeNameForComment = "syed_comment";
        public const string SourceControlQueueAttributeNameForOwnerId = "ownerid";
        public const string SourceControlQueueAttributeNameForIncludeInRelease = "syed_includeinrelease";
        public const string SourceControlQueueAttributeNameForCheckinSolution = "syed_checkin";
        public const string SourceControlQueueAttributeNameForMergeSolution = "syed_mergesolutions";
        public const string SourceControlQueueAttributeNameForSourceSolutions = "syed_sourcensolutions";

        public static List<int> ComponentTypes = new List<int> {
                1,// entities
                    2, // Attribut
                    10, // Relationship
                    14, // Key
                    22, // Display string
                    24, // Form
                    26, // View
                    59, // Chart
                    60, // System Form
                    65, // Hierarchical rules

                    62, //sitempas
                    50, //ribbon
                    9, //Global optionsets
                    91, // plugin assemblies
                    92, // Sdk message processing steps
                    95, // service endpoints
                    31, // Reports
                    20, // Roles
                    70, // field security profile
                    63, // connection roles
                    61, // web resources
                    29, // work flows
                    38,// kb article templates
                    39,// mail merge templates
                    37,// contract templates
                    36,// email templates
                    60, // Dashboards
                    150,// routing rules
                    152,// slas
                    154 //convert rules


                };
    }
}
