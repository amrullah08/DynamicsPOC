﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{

    internal interface ICrmSolutionHelper
    {
        string RepositoryUrl { get; set; }
        string Branch { get; set; }

        bool CanPush { get; set; }

        List<SolutionFileInfo> SolutionFileInfos { get; set; }

        List<SolutionFileInfo> DownloadSolutionFile(string solutionUnqiueName, string owner, string message);
    }
}
