﻿using Microsoft.Xrm.Sdk;
using System.Collections.Generic;

namespace ConsoleApp10
{
    public class SolutionFileInfo
    {

        public string SolutionFilePath;
        public string SolutionUniqueName;
        public Entity Solution;
        public string Message;
        public string OwnerName;
        public bool IncludeInRelease, CheckInSolution, MergeSolution;
        public List<string> SolutionsToBeMerged = new List<string>();
        public Microsoft.Xrm.Sdk.Client.OrganizationServiceProxy OrganizationServiceProxy { get; set; }

        public SolutionFileInfo(Microsoft.Xrm.Sdk.Client.OrganizationServiceProxy organizationServiceProxy)
        {
            this.OrganizationServiceProxy = organizationServiceProxy;
        }

        public SolutionFileInfo(Entity solution, Microsoft.Xrm.Sdk.Client.OrganizationServiceProxy organizationServiceProxy)
        {
            this.OrganizationServiceProxy = organizationServiceProxy;
            SolutionUniqueName = solution.GetAttributeValue<string>(Constants.SourceControlQueueAttributeNameForSolutionName);
            Message = solution.GetAttributeValue<string>(Constants.SourceControlQueueAttributeNameForComment);
            OwnerName = solution.GetAttributeValue<EntityReference>(Constants.SourceControlQueueAttributeNameForOwnerId).Name;
            IncludeInRelease = solution.GetAttributeValue<bool>(Constants.SourceControlQueueAttributeNameForIncludeInRelease);
            CheckInSolution = solution.GetAttributeValue<bool>(Constants.SourceControlQueueAttributeNameForCheckinSolution);
            MergeSolution = solution.GetAttributeValue<bool>(Constants.SourceControlQueueAttributeNameForMergeSolution);
            var solutions = solution.GetAttributeValue<string>(Constants.SourceControlQueueAttributeNameForSourceSolutions);

            if (!string.IsNullOrEmpty(solutions) && MergeSolution)
            {
                foreach (var s in solutions.Split(new string[] { "," }, System.StringSplitOptions.RemoveEmptyEntries))
                {
                    SolutionsToBeMerged.Add(s);
                }
            }
            Solution = solution;
        }

        public void Update()
        {
                OrganizationServiceProxy.Update(Solution);
        }
    }
}