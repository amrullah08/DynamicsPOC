﻿using ConsoleApp10;
using LibGit2Sharp;
using LibGit2Sharp.Handlers;
using System;
using System.IO;
using System.Linq;

namespace GitDeploy
{
    public class GitRepositoryManager : IGitRepositoryManager
    {
        private readonly string _repoSource, _authorName, _authorEmail, _committerName, _committerEmail, _remoteName, _branchName;
        bool _cloneAlways;
        private readonly UsernamePasswordCredentials _credentials;
        private readonly DirectoryInfo _localFolder;

        /// <summary>
        /// Initializes a new instance of the <see cref="GitRepositoryManager" /> class.
        /// </summary>
        /// <param name="username">The Git credentials username.</param>
        /// <param name="password">The Git credentials password.</param>
        /// <param name="gitRepoUrl">The Git repo URL.</param>
        /// <param name="localFolder">The full path to local folder.</param>
        public GitRepositoryManager(string username, string password, string gitRepoUrl, 
            string remoteName, string branchName, bool cloneAlways,
            string localFolder,
            string authorname,
            string authoremail,
            string committername,
            string committeremail)
        {
            var folder = new DirectoryInfo(localFolder);

            //if (!folder.Exists)
            //{
            //    throw new Exception(string.Format("Source folder '{0}' does not exist.", _localFolder));
            //}

            _localFolder = folder;

            _credentials = new UsernamePasswordCredentials
            {
                Username = username,
                Password = password
            };

            _repoSource = gitRepoUrl;

            _authorName = authorname;
            _authorEmail = authoremail;
            _committerName = committername;
            _committerEmail = committeremail;

            _remoteName = remoteName;
            _branchName = branchName;
            _cloneAlways = cloneAlways;
        }

        /// <summary>
        /// Commits all changes.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <exception cref="System.Exception"></exception>
        public void CommitAllChanges(SolutionFileInfo solutionFileInfo, string solutionFilePath)
        {
            try
            {
                Console.WriteLine("Committing solutions");
                string file = _localFolder + solutionFileInfo.SolutionUniqueName + "_.zip";
                File.Copy(solutionFileInfo.SolutionFilePath, file, true);
                using (var repo = new Repository(_localFolder.FullName))
                {
                    if (string.IsNullOrEmpty(file))
                    {
                        //var files = _localFolder.GetFiles("*.zip", SearchOption.AllDirectories).Select(f => f.FullName);
                        var files = _localFolder.GetFiles("*.zip").Select(f => f.FullName);
                        //string message = commitMessage + " ";

                        {
                            foreach (var f in files)
                            {
                                if (string.IsNullOrEmpty(file))
                                {
                                    //message += k + ",";
                                    repo.Index.Add(f.Replace(_localFolder.FullName, string.Empty));
                                }
                                else
                                {
                                    if (f.EndsWith(file))
                                        repo.Index.Add(f.Replace(_localFolder.FullName, string.Empty));
                                }
                            }
                        }
                    }
                    else
                    {
                        repo.Index.Add(file.Replace(_localFolder.FullName, string.Empty));
                    }

                    repo.Index.Add(solutionFilePath.Replace(_localFolder.FullName, string.Empty));

                    var offset = DateTimeOffset.Now;
                    Signature author = new Signature(_authorName, _authorEmail, offset);
                    Signature committer = new Signature(_committerName, _committerEmail, offset);
                    CommitOptions commitOptions = new CommitOptions();
                    commitOptions.AllowEmptyCommit = false;

                    repo.Commit(solutionFileInfo.Message, author, committer);
                }
            }
            catch (EmptyCommitException ex)
            {
                Console.WriteLine(ex);
            }
        }

        /// <summary>
        /// Pushes all commits.
        /// </summary>
        /// <param name="remoteName">Name of the remote server.</param>
        /// <param name="branchName">Name of the remote branch.</param>
        /// <exception cref="System.Exception"></exception>
        public void PushCommits()
        {
            string remoteName = _remoteName, branchName = _branchName;
            using (var repo = new Repository(_localFolder.FullName))
            {
                var remote = repo.Network.Remotes.FirstOrDefault(r => r.Name == remoteName);
                if (remote == null)
                {
                    repo.Network.Remotes.Add(remoteName, _repoSource);
                    remote = repo.Network.Remotes.FirstOrDefault(r => r.Name == remoteName);
                }
                var options = new PushOptions
                {
                    CredentialsProvider = (url, usernameFromUrl, types) => _credentials
                };

                options.OnPushStatusError += PushSatusErrorHandler;

                string pushRefs = "refs/heads/testsyed";
                Branch branchs = null;
                foreach (var branch in repo.Branches)
                {
                    if (branch.FriendlyName.ToLower().Equals(branchName.ToLower()))
                    {
                        branchs = branch;
                        pushRefs = branch.Reference.CanonicalName;
                    }
                }

                Console.WriteLine("Pushing Changes to the Repository ");
                //repo.Network.Push(branchs);
                repo.Network.Push(remote, pushRefs + ":" + pushRefs, options);
                try
                {
                    repo.Network.Push(repo.Network.Remotes.FirstOrDefault(r => r.Name == "remotes/origin"), pushRefs, options);
                }
                catch(Exception e)
                {

                }
                Console.WriteLine("Pushed changes");
            }
        }

        private void PushSatusErrorHandler(PushStatusError pushStatusErrors)
        {
            throw new NotImplementedException();
        }

        //https://github.com/libgit2/libgit2sharp/blob/2f8ad262b7613e9e68aefd4f55956bf24b05d042/LibGit2Sharp.Tests/MergeFixture.cs
        //https://github.com/libgit2/libgit2sharp/blob/2f8ad262b7613e9e68aefd4f55956bf24b05d042/LibGit2Sharp.Tests/FetchFixture.cs#L129-L153
        public void UpdateRepository()
        {
            string remoteName = _remoteName, branchName = _branchName;
            bool cloneAlways = _cloneAlways;
            string url = this._repoSource;
            CredentialsHandler crednt = (curl, usernameFromUrl, types) => _credentials;
            //C:\Syed\1\Compass Commissioning\
            string workingDirectory = _localFolder.FullName;
            if (Directory.Exists(workingDirectory))
            {
                if (!cloneAlways)
                {
                    try
                    {
                        using (var repo = new Repository(workingDirectory))
                        {
                            repo.Reset(ResetMode.Hard);
                            repo.RemoveUntrackedFiles();

                            var remote = repo.Network.Remotes.FirstOrDefault(r => r.Name == remoteName);
                            
                            string pushRefs = "refs/heads/testsyed";
                            Branch branchs = null;
                            foreach (var branch in repo.Branches)
                            {
                                if (branch.FriendlyName.ToLower().Equals(branchName.ToLower()))
                                {
                                    branchs = branch;
                                    pushRefs = branch.Reference.CanonicalName;
                                }
                            }


                            var fetchOptions = new FetchOptions() { CredentialsProvider = crednt };

                            repo.Network.Fetch(remote.Name, new string[] { pushRefs }, fetchOptions);


                            PullOptions pullOptions = new PullOptions()
                            {
                                MergeOptions = new MergeOptions()
                                {
                                    FastForwardStrategy = FastForwardStrategy.Default,
                                },
                                FetchOptions = fetchOptions
                            };

                            MergeResult mergeResult = Commands.Pull(
                                repo,
                                new Signature(_authorName, _authorEmail, DateTimeOffset.Now),
                                pullOptions
                            );
                        }
                        return;
                    }
                    catch (LibGit2Sharp.RepositoryNotFoundException r)
                    {
                    }
                }
                else
                {
                    try
                    {
                        DirectoryInfo attachments_AR = new DirectoryInfo(workingDirectory);
                        EmptyFolder(attachments_AR);
                    }
                    catch
                    {

                    }
                }
            }
            else
            {
                
                Directory.CreateDirectory(workingDirectory);
            }
            var cloneOptions = new CloneOptions
            {
                CredentialsProvider = crednt
            };

            cloneOptions.BranchName = branchName;

            Repository.Clone(url, workingDirectory, cloneOptions);
        }
        private static void EmptyFolder(DirectoryInfo directory)
        {
            foreach (FileInfo file in directory.GetFiles())
            {
                file.Delete();
            }

            foreach (DirectoryInfo subdirectory in directory.GetDirectories())
            {
                EmptyFolder(subdirectory);
                subdirectory.Delete();
            }
        }

        public static bool IsDirectoryEmpty(string path)
        {
            return !Directory.EnumerateFileSystemEntries(path).Any();
        }
    }

    public interface IGitRepositoryManager
    {
        void CommitAllChanges(SolutionFileInfo solutionFileInfo, string solutionFilePath);

        void PushCommits();
        void UpdateRepository();
    }
}